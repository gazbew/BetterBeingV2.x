import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Star, ShoppingCart, Heart, Zap, Shield, Leaf } from "lucide-react";
import productsImage from "@/assets/products-showcase.jpg";

const products = [
  {
    id: 1,
    name: "Vitality Boost Complex",
    description: "Premium herbal blend for natural energy and mental clarity",
    price: "$89",
    originalPrice: "$129",
    rating: 4.9,
    reviews: 2847,
    benefits: ["Increased Energy", "Mental Clarity", "Stress Relief"],
    icon: Zap,
    popular: true
  },
  {
    id: 2,
    name: "Pure Wellness Elixir",
    description: "Ancient botanical formula for overall health optimization",
    price: "$124",
    originalPrice: "$179",
    rating: 4.8,
    reviews: 1923,
    benefits: ["Immune Support", "Anti-Aging", "Detox"],
    icon: Shield,
    popular: false
  },
  {
    id: 3,
    name: "Harmony Sleep Formula",
    description: "Natural sleep enhancement with premium herbs and minerals",
    price: "$67",
    originalPrice: "$89",
    rating: 4.9,
    reviews: 3241,
    benefits: ["Deep Sleep", "Recovery", "Calm Mind"],
    icon: Leaf,
    popular: false
  }
];

export const ProductsSection = () => {
  return (
    <section id="products" className="py-20 bg-gradient-wellness">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <div className="inline-flex items-center space-x-2 bg-accent/10 rounded-full px-6 py-2 mb-6">
            <Leaf className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-primary">Premium Products</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-primary mb-6">
            Scientifically-Crafted
            <span className="block text-accent">Wellness Solutions</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Each product is meticulously formulated using the finest natural ingredients, 
            backed by cutting-edge research and trusted by thousands worldwide.
          </p>
        </div>

        {/* Featured Image */}
        <div className="relative mb-16 animate-scale-in">
          <div className="relative overflow-hidden rounded-3xl shadow-floating">
            <img 
              src={productsImage} 
              alt="Premium wellness products showcase"
              className="w-full h-64 md:h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent" />
            <div className="absolute bottom-8 left-8 text-primary-foreground">
              <h3 className="text-2xl font-bold mb-2">Premium Quality Guaranteed</h3>
              <p className="text-primary-foreground/90">Lab-tested • Third-party verified • Sustainably sourced</p>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {products.map((product, index) => (
            <Card 
              key={product.id} 
              className="relative group hover:shadow-wellness transition-all duration-500 hover:-translate-y-2 border-0 bg-card/60 backdrop-blur-sm"
              style={{ animationDelay: `${index * 200}ms` }}
            >
              {product.popular && (
                <div className="absolute -top-3 left-6 bg-accent text-accent-foreground px-4 py-1 rounded-full text-sm font-medium z-10">
                  Most Popular
                </div>
              )}
              
              <CardContent className="p-8">
                {/* Product Icon */}
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <product.icon className="w-8 h-8 text-primary" />
                </div>

                {/* Product Info */}
                <h3 className="text-2xl font-bold text-primary mb-3">{product.name}</h3>
                <p className="text-muted-foreground mb-6">{product.description}</p>

                {/* Benefits */}
                <div className="space-y-2 mb-6">
                  {product.benefits.map((benefit, i) => (
                    <div key={i} className="flex items-center space-x-2 text-sm">
                      <div className="w-1.5 h-1.5 bg-accent rounded-full" />
                      <span className="text-foreground">{benefit}</span>
                    </div>
                  ))}
                </div>

                {/* Rating */}
                <div className="flex items-center space-x-2 mb-6">
                  <div className="flex text-accent">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {product.rating} ({product.reviews.toLocaleString()} reviews)
                  </span>
                </div>

                {/* Price */}
                <div className="flex items-center space-x-3 mb-6">
                  <span className="text-3xl font-bold text-primary">{product.price}</span>
                  <span className="text-lg text-muted-foreground line-through">{product.originalPrice}</span>
                  <span className="bg-accent/20 text-accent px-2 py-1 rounded text-sm font-medium">
                    Save {Math.round((1 - parseInt(product.price.slice(1)) / parseInt(product.originalPrice.slice(1))) * 100)}%
                  </span>
                </div>

                {/* Actions */}
                <div className="flex space-x-3">
                  <Button className="flex-1 bg-primary hover:bg-primary/90 shadow-wellness">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Add to Cart
                  </Button>
                  <Button variant="outline" size="icon" className="shrink-0">
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center animate-fade-in-up">
          <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground text-lg px-8 py-4">
            View All Products
          </Button>
        </div>
      </div>
    </section>
  );
};